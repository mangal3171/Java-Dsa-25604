/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	Long Timestamp = 1633304782;
Date timeD = new Date(Timestamp * 1000);
SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

String Time = sdf.format(timeD);
	}
}
